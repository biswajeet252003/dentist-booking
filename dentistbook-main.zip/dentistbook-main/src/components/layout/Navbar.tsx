
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, SmilePlus } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <SmilePlus className="h-8 w-8 text-nature-sage" />
              <span className="ml-2 text-xl font-bold text-nature-sage">WeCare</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link
                to="/"
                className={`inline-flex items-center px-1 pt-1 ${isActive('/') ? 'nav-link-active' : 'nav-link'}`}
              >
                Home
              </Link>
              <Link
                to="/services"
                className={`inline-flex items-center px-1 pt-1 ${isActive('/services') ? 'nav-link-active' : 'nav-link'}`}
              >
                Services
              </Link>
              <Link
                to="/dentists"
                className={`inline-flex items-center px-1 pt-1 ${isActive('/dentists') ? 'nav-link-active' : 'nav-link'}`}
              >
                Our Dentists
              </Link>
              <Link
                to="/contact"
                className={`inline-flex items-center px-1 pt-1 ${isActive('/contact') ? 'nav-link-active' : 'nav-link'}`}
              >
                Contact
              </Link>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            <Button asChild variant="default" className="btn-nature">
              <Link to="/book" className="inline-flex items-center px-4 py-2">
                Book Appointment
              </Link>
            </Button>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-nature-sage hover:text-nature-mint hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-nature-mint"
            >
              <span className="sr-only">{isOpen ? 'Close main menu' : 'Open main menu'}</span>
              {isOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block pl-3 pr-4 py-2 ${isActive('/') ? 'bg-nature-pale border-l-4 border-nature-mint text-nature-sage' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-nature-sage block pl-3 pr-4 py-2 border-l-4 text-base font-medium'}`}
              onClick={() => setIsOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/services"
              className={`block pl-3 pr-4 py-2 ${isActive('/services') ? 'bg-nature-pale border-l-4 border-nature-mint text-nature-sage' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-nature-sage block pl-3 pr-4 py-2 border-l-4 text-base font-medium'}`}
              onClick={() => setIsOpen(false)}
            >
              Services
            </Link>
            <Link
              to="/dentists"
              className={`block pl-3 pr-4 py-2 ${isActive('/dentists') ? 'bg-nature-pale border-l-4 border-nature-mint text-nature-sage' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-nature-sage block pl-3 pr-4 py-2 border-l-4 text-base font-medium'}`}
              onClick={() => setIsOpen(false)}
            >
              Our Dentists
            </Link>
            <Link
              to="/contact"
              className={`block pl-3 pr-4 py-2 ${isActive('/contact') ? 'bg-nature-pale border-l-4 border-nature-mint text-nature-sage' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-nature-sage block pl-3 pr-4 py-2 border-l-4 text-base font-medium'}`}
              onClick={() => setIsOpen(false)}
            >
              Contact
            </Link>
            <Link
              to="/book"
              className="block w-full text-center px-4 py-2 bg-nature-sage text-white font-medium rounded-md mt-4 mx-3"
              onClick={() => setIsOpen(false)}
            >
              Book Appointment
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
