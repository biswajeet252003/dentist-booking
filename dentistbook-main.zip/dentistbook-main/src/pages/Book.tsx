
import { useState } from "react";
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Check, CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export default function Book() {
  const [date, setDate] = useState<Date>();
  const [step, setStep] = useState(1);
  const [selectedTime, setSelectedTime] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    dentist: "",
    service: "",
    notes: "",
  });

  const times = [
    "9:00 AM", "10:00 AM", "11:00 AM", 
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"
  ];

  const services = [
    "Dental Cleaning", 
    "Dental Exam", 
    "Teeth Whitening", 
    "Dental Fillings", 
    "Root Canal", 
    "Dental Crown", 
    "Tooth Extraction"
  ];

  const nextStep = () => {
    if (step === 1 && !date) {
      toast({
        title: "Please select a date",
        description: "You need to select an appointment date to continue",
        variant: "destructive",
      });
      return;
    }

    if (step === 2 && !selectedTime) {
      toast({
        title: "Please select a time",
        description: "You need to select an appointment time to continue",
        variant: "destructive",
      });
      return;
    }

    if (step === 3) {
      const { name, email, phone, service } = formData;
      if (!name || !email || !phone || !service) {
        toast({
          title: "Missing information",
          description: "Please fill out all required fields",
          variant: "destructive",
        });
        return;
      }
    }

    if (step < 4) {
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = () => {
    toast({
      title: "Appointment Booked!",
      description: `Your appointment is scheduled for ${format(date as Date, "PPP")} at ${selectedTime}`,
    });
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-nature-sage/90 to-nature-mint/80 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4 text-shadow">Book Your Dental Appointment</h1>
            <p className="text-xl max-w-3xl mx-auto">
              Schedule your visit with our experienced dental team and take the first step toward a healthier smile.
            </p>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-16 bg-nature-pale/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white shadow-lg rounded-2xl overflow-hidden">
            {/* Progress Steps */}
            <div className="bg-nature-sage/20 p-6">
              <div className="flex justify-between items-center">
                {[1, 2, 3, 4].map((item) => (
                  <div key={item} className="flex flex-col items-center">
                    <div 
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        step >= item ? 'bg-nature-sage text-white' : 'bg-gray-200 text-gray-500'
                      }`}
                    >
                      {step > item ? <Check size={18} /> : item}
                    </div>
                    <span className="text-sm mt-2 text-gray-600">
                      {item === 1 && "Date"}
                      {item === 2 && "Time"}
                      {item === 3 && "Details"}
                      {item === 4 && "Confirmation"}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="p-8">
              {step === 1 && (
                <div className="flex flex-col items-center">
                  <h2 className="text-2xl font-semibold mb-6 text-nature-sage">Select Appointment Date</h2>
                  <div className="rounded-md border border-nature-mint/30 p-2 bg-white">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="border-none"
                      disabled={(date) => {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        
                        // Disable past dates, Sundays (day 0), and Saturdays (day 6)
                        return date < today || date.getDay() === 0 || date.getDay() === 6;
                      }}
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="flex flex-col items-center">
                  <h2 className="text-2xl font-semibold mb-6 text-nature-sage">Select Appointment Time</h2>
                  <p className="text-gray-600 mb-6">
                    Selected Date: <span className="font-medium">{format(date as Date, "PPPP")}</span>
                  </p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full">
                    {times.map((time) => (
                      <Button
                        key={time}
                        type="button"
                        variant={selectedTime === time ? "default" : "outline"}
                        className={`h-14 ${selectedTime === time ? 'bg-nature-sage text-white' : 'hover:bg-nature-pale'}`}
                        onClick={() => setSelectedTime(time)}
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {step === 3 && (
                <div>
                  <h2 className="text-2xl font-semibold mb-6 text-nature-sage text-center">Enter Your Details</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="name">Full Name *</label>
                      <Input 
                        id="name" 
                        name="name"
                        value={formData.name}
                        onChange={handleChange} 
                        className="border-nature-mint/40 focus:border-nature-mint" 
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="email">Email Address *</label>
                      <Input 
                        id="email" 
                        name="email" 
                        type="email"
                        value={formData.email}
                        onChange={handleChange} 
                        className="border-nature-mint/40 focus:border-nature-mint" 
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="phone">Phone Number *</label>
                      <Input 
                        id="phone" 
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange} 
                        className="border-nature-mint/40 focus:border-nature-mint" 
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="service">Service *</label>
                      <Select
                        value={formData.service}
                        onValueChange={(value) => handleSelectChange("service", value)}
                      >
                        <SelectTrigger id="service" className="border-nature-mint/40 focus:border-nature-mint">
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          {services.map((service) => (
                            <SelectItem key={service} value={service}>
                              {service}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="dentist">Preferred Dentist (Optional)</label>
                      <Select
                        value={formData.dentist}
                        onValueChange={(value) => handleSelectChange("dentist", value)}
                      >
                        <SelectTrigger id="dentist" className="border-nature-mint/40 focus:border-nature-mint">
                          <SelectValue placeholder="Any dentist is fine" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="any-dentist">Any dentist is fine</SelectItem>
                          <SelectItem value="dr-johnson">Dr. Sarah Johnson</SelectItem>
                          <SelectItem value="dr-chen">Dr. Michael Chen</SelectItem>
                          <SelectItem value="dr-wilson">Dr. James Wilson</SelectItem>
                          <SelectItem value="dr-gonzalez">Dr. Maria Gonzalez</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm font-medium text-gray-600" htmlFor="notes">Notes (Optional)</label>
                      <Textarea 
                        id="notes" 
                        name="notes"
                        value={formData.notes}
                        onChange={handleChange} 
                        rows={4} 
                        className="border-nature-mint/40 focus:border-nature-mint resize-none" 
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-2 text-nature-sage">Appointment Summary</h2>
                  <p className="text-gray-600 mb-6">Please review your appointment details</p>
                  
                  <Card className="w-full mb-6">
                    <CardContent className="pt-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Date & Time</h3>
                          <p className="text-gray-900">{format(date as Date, "PPPP")} at {selectedTime}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Service</h3>
                          <p className="text-gray-900">{formData.service}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Name</h3>
                          <p className="text-gray-900">{formData.name}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Contact</h3>
                          <p className="text-gray-900">{formData.email}</p>
                          <p className="text-gray-900">{formData.phone}</p>
                        </div>
                        {formData.dentist && (
                          <div>
                            <h3 className="text-sm font-medium text-gray-500">Preferred Dentist</h3>
                            <p className="text-gray-900">
                              {formData.dentist === "any-dentist" ? "Any dentist" : 
                               formData.dentist === "dr-johnson" ? "Dr. Sarah Johnson" :
                               formData.dentist === "dr-chen" ? "Dr. Michael Chen" :
                               formData.dentist === "dr-wilson" ? "Dr. James Wilson" :
                               "Dr. Maria Gonzalez"}
                            </p>
                          </div>
                        )}
                        {formData.notes && (
                          <div className="md:col-span-2">
                            <h3 className="text-sm font-medium text-gray-500">Notes</h3>
                            <p className="text-gray-900">{formData.notes}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div className="flex flex-col space-y-4 w-full">
                    <Button onClick={handleSubmit} className="bg-nature-sage hover:bg-nature-sage/90">
                      Confirm Booking
                    </Button>
                  </div>
                </div>
              )}

              <div className={`flex ${step > 1 ? 'justify-between' : 'justify-end'} mt-8`}>
                {step > 1 && (
                  <Button variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                )}
                {step < 4 && (
                  <Button onClick={nextStep} className="bg-nature-sage hover:bg-nature-sage/90">
                    Continue
                  </Button>
                )}
              </div>
            </div>
          </div>
          
          {/* Benefits */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">Why Choose WeCare Dental</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-sm text-center card-hover">
                <img 
                  src="https://images.unsplash.com/photo-1606811971618-4486d14f3f99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="Expert Dentist Team" 
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold mb-2 text-nature-sage">Expert Dentists</h3>
                <p className="text-gray-600">Our team of experienced professionals is committed to providing the highest quality dental care.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm text-center card-hover">
                <img 
                  src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="Modern Dental Equipment" 
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold mb-2 text-nature-sage">Modern Technology</h3>
                <p className="text-gray-600">We utilize the latest dental technology to ensure precise diagnosis and comfortable treatment.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm text-center card-hover">
                <img 
                  src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="Comfortable Dental Environment" 
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
                <h3 className="text-lg font-semibold mb-2 text-nature-sage">Comfortable Environment</h3>
                <p className="text-gray-600">Our welcoming office is designed to make your dental visit as relaxing and comfortable as possible.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
