
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const Dentists = () => {
  const dentists = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      title: "General Dentist",
      description: "Dr. Johnson has over 15 years of experience in general dentistry, focusing on preventive care and cosmetic procedures. She earned her DDS from the University of Michigan and is passionate about patient education.",
      specialties: ["General Dentistry", "Cosmetic Dentistry", "Preventive Care"],
      education: "DDS, University of Michigan",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      title: "Orthodontist",
      description: "Dr. Chen specializes in orthodontics with a focus on modern alignment techniques including Invisalign. He completed his orthodontic specialty training at UCLA after earning his DDS from NYU College of Dentistry.",
      specialties: ["Orthodontics", "Invisalign", "Braces"],
      education: "DDS, NYU College of Dentistry; MS in Orthodontics, UCLA",
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 3,
      name: "Dr. James Wilson",
      title: "Oral Surgeon",
      description: "Dr. Wilson is our resident oral surgeon with expertise in extractions, implants, and jaw surgery. He earned his DMD from Harvard School of Dental Medicine followed by specialized surgical training at Mayo Clinic.",
      specialties: ["Oral Surgery", "Dental Implants", "Wisdom Teeth"],
      education: "DMD, Harvard School of Dental Medicine",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 4,
      name: "Dr. Maria Gonzalez",
      title: "Pediatric Dentist",
      description: "Dr. Gonzalez specializes in pediatric dentistry, creating positive dental experiences for our youngest patients. She earned her DDS from UCSF and completed pediatric specialty training at Boston Children's Hospital.",
      specialties: ["Pediatric Dentistry", "Child Dental Development", "Special Needs"],
      education: "DDS, UCSF; Certificate in Pediatric Dentistry",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-nature-gradient text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Meet Our Dental Team</h1>
            <p className="text-xl max-w-3xl mx-auto">
              Our team of experienced dental professionals is committed to providing the highest quality care in a comfortable environment.
            </p>
          </div>
        </div>
      </section>

      {/* Team Members */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12">
            {dentists.map((dentist, index) => (
              <div key={dentist.id} className={`grid grid-cols-1 lg:grid-cols-2 gap-10 ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="flex flex-col justify-center">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">{dentist.name}</h2>
                  <h3 className="text-xl text-nature-sage mb-4">{dentist.title}</h3>
                  <p className="text-lg text-gray-600 mb-6">{dentist.description}</p>
                  
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Specialties:</h4>
                    <div className="flex flex-wrap gap-2">
                      {dentist.specialties.map((specialty, i) => (
                        <span key={i} className="bg-nature-pale text-nature-sage px-3 py-1 rounded-full text-sm">
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Education:</h4>
                    <p className="text-gray-700">{dentist.education}</p>
                  </div>
                  
                  <Button asChild className="self-start bg-nature-sage hover:bg-nature-sage/90">
                    <Link to="/book">
                      Book with {dentist.name.split(' ')[0]}
                    </Link>
                  </Button>
                </div>
                <div className="h-[400px] flex items-center justify-center overflow-hidden rounded-lg shadow-md">
                  <img 
                    src={dentist.image} 
                    alt={dentist.name} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-nature-pale py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Meet Our Team in Person?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Schedule your appointment today and experience the difference our dental professionals can make for your oral health.
            </p>
            <Button asChild size="lg" className="bg-nature-sage hover:bg-nature-sage/90">
              <Link to="/book">Book an Appointment</Link>
            </Button>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default Dentists;
