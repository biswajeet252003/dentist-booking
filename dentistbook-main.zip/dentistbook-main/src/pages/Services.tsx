
import MainLayout from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { CheckCircle, Shield, Star, Users, Clock, ArrowRight } from "lucide-react";

const Services = () => {
  const services = [
    {
      id: 1,
      title: "Preventive Dentistry",
      description: "Our preventive care focuses on maintaining good oral health and preventing dental issues before they start.",
      icon: <Shield className="h-6 w-6" />,
      treatments: [
        "Comprehensive Dental Exams",
        "Professional Teeth Cleaning",
        "Digital X-rays",
        "Oral Cancer Screenings",
        "Fluoride Treatments",
        "Dental Sealants"
      ],
      image: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 2,
      title: "Cosmetic Dentistry",
      description: "Enhance your smile's appearance with our range of cosmetic dental procedures.",
      icon: <Star className="h-6 w-6" />,
      treatments: [
        "Teeth Whitening",
        "Porcelain Veneers",
        "Dental Bonding",
        "Gum Contouring",
        "Smile Makeovers",
        "Tooth-Colored Fillings"
      ],
      image: "https://images.unsplash.com/photo-1581585375706-479e7aafe4af?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 3,
      title: "Restorative Dentistry",
      description: "Restore function and appearance to damaged or missing teeth with our restorative treatments.",
      icon: <CheckCircle className="h-6 w-6" />,
      treatments: [
        "Dental Crowns",
        "Dental Bridges",
        "Dental Implants",
        "Dentures & Partials",
        "Root Canal Therapy",
        "Inlays & Onlays"
      ],
      image: "https://images.unsplash.com/photo-1606265752439-1f18756eb893?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 4,
      title: "Pediatric Dentistry",
      description: "Special dental care for children in a friendly and comfortable environment.",
      icon: <Users className="h-6 w-6" />,
      treatments: [
        "Child Dental Exams",
        "Gentle Cleanings",
        "Fluoride Treatments",
        "Dental Sealants",
        "Space Maintainers",
        "Pediatric Dental Education"
      ],
      image: "https://images.unsplash.com/photo-1606265752439-1f18756eb893?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 5,
      title: "Emergency Dentistry",
      description: "Quick and effective care for dental emergencies to relieve pain and prevent further damage.",
      icon: <Clock className="h-6 w-6" />,
      treatments: [
        "Same-Day Appointments",
        "Toothache Relief",
        "Broken Tooth Repair",
        "Lost Filling or Crown Replacement",
        "Abscess Treatment",
        "Trauma Care"
      ],
      image: "https://images.unsplash.com/photo-1620775997990-1a7882cc26e8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: 6,
      title: "Oral Surgery",
      description: "Specialized surgical procedures performed with precision and care.",
      icon: <Shield className="h-6 w-6" />,
      treatments: [
        "Tooth Extractions",
        "Wisdom Teeth Removal",
        "Dental Implant Placement",
        "Bone Grafting",
        "Jaw Surgery",
        "Biopsy Procedures"
      ],
      image: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80"
    }
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="bg-nature-gradient text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Our Dental Services</h1>
            <p className="text-xl max-w-3xl mx-auto">
              Comprehensive dental care for you and your family, with a focus on comfort and lasting results.
            </p>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12">
            {services.map((service, index) => (
              <div key={service.id} className={`grid grid-cols-1 lg:grid-cols-2 gap-10 ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="flex flex-col justify-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-nature-pale text-nature-sage mb-4">
                    {service.icon}
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">{service.title}</h2>
                  <p className="text-lg text-gray-600 mb-6">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.treatments.map((treatment, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-nature-sage mr-2 mt-1 flex-shrink-0" />
                        <span className="text-gray-700">{treatment}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild className="self-start bg-nature-sage hover:bg-nature-sage/90">
                    <Link to="/book">
                      Book This Service
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
                <div className="rounded-lg h-[300px] flex items-center justify-center overflow-hidden shadow-md">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-nature-pale py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Have Questions About Our Services?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Our team is here to help you understand your treatment options and find the right solution for your dental needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-nature-sage hover:bg-nature-sage/90">
                <Link to="/book">Book an Appointment</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-nature-sage text-nature-sage hover:bg-nature-pale">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default Services;
