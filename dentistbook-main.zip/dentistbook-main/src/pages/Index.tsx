
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import MainLayout from "@/components/layout/MainLayout";
import { Calendar, Shield, Clock, Star, Users, CheckCircle, ArrowRight, Image } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";

const Index = () => {
  const testimonials = [
    {
      name: "Sarah Thompson",
      role: "Patient",
      quote: "The team at WeCare Dental made my dental experience comfortable and stress-free. I'm thrilled with the results of my treatment!",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Michael Rodriguez",
      role: "Patient",
      quote: "I've been coming to WeCare Dental for years and have always received excellent care. The staff is friendly and professional.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
    },
    {
      name: "Emily Johnson",
      role: "Patient",
      quote: "As someone who used to be anxious about dental visits, I can't recommend WeCare Dental enough. They truly put patient comfort first.",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
    }
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-nature-sage/90 to-nature-mint/80 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6 text-shadow">Your Smile Deserves The Best Care</h1>
              <p className="text-lg md:text-xl mb-8">
                Experience top-quality dental care in a comfortable and friendly environment.
                Schedule your appointment today and start your journey to a healthier smile.
              </p>
              <div className="space-x-4">
                <Button asChild size="lg" className="bg-white text-nature-sage hover:bg-nature-cream">
                  <Link to="/book">Book Appointment</Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-nature-sage">
                  <Link to="/services">Our Services</Link>
                </Button>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1521795251022-83a9e4cd1c0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" 
                alt="Happy patient with healthy smile" 
                className="w-full rounded-lg shadow-xl object-cover h-[400px]"
                loading="eager"
              />
            </div>
          </div>
        </div>
      </section>

      {/* New Banner Section */}
      <section className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-xl shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2000&q=80" 
              alt="Modern dental clinic" 
              className="w-full h-[300px] object-cover"
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-nature-sage/80 to-transparent flex items-center">
              <div className="max-w-2xl px-8 md:px-12">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">State-of-the-Art Dental Technology</h2>
                <p className="text-white/90 text-lg mb-6">Experience comfortable treatments with our advanced equipment and skilled professionals.</p>
                <Button asChild className="bg-white text-nature-sage hover:bg-nature-cream">
                  <Link to="/services">Learn More</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose WeCare Dental?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're committed to providing exceptional dental care with a focus on comfort and the latest technology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-nature-pale p-6 rounded-lg text-center shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-nature-sage/20 text-nature-sage mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Advanced Technology</h3>
              <p className="text-gray-600">
                We utilize the latest dental technology to ensure precise diagnosis and comfortable treatment.
              </p>
            </div>

            <div className="bg-nature-pale p-6 rounded-lg text-center shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-nature-sage/20 text-nature-sage mb-4">
                <Star className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Experienced Dentists</h3>
              <p className="text-gray-600">
                Our team of skilled professionals has years of experience in all aspects of dentistry.
              </p>
            </div>

            <div className="bg-nature-pale p-6 rounded-lg text-center shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-nature-sage/20 text-nature-sage mb-4">
                <Calendar className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Easy Scheduling</h3>
              <p className="text-gray-600">
                Book appointments online at your convenience, with flexible scheduling options.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Dental Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We offer comprehensive dental services to meet all your oral health needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "General Dentistry",
                description: "Comprehensive checkups, cleanings, and preventive care to maintain oral health.",
                icon: <CheckCircle className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1606811971618-4486d14f3f99?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Cosmetic Dentistry",
                description: "Transform your smile with our cosmetic services, including whitening and veneers.",
                icon: <Star className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1595003480910-904ca4578d66?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Restorative Dentistry",
                description: "Restore function and appearance with crowns, bridges, and implants.",
                icon: <Users className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1581772795843-d087bd06a5e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Pediatric Dentistry",
                description: "Specialized care for children's dental needs in a friendly environment.",
                icon: <Users className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1602891676890-c2d87527e6f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Emergency Dentistry",
                description: "Quick care for dental emergencies to alleviate pain and prevent complications.",
                icon: <Clock className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1584556812952-905ffd0c611a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              },
              {
                title: "Oral Surgery",
                description: "Expert surgical procedures including extractions and implant placement.",
                icon: <Shield className="h-6 w-6" />,
                image: "https://images.unsplash.com/photo-1609840114035-3c981b782dfe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80"
              }
            ].map((service, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden card-hover">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-nature-pale text-nature-sage mb-4">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <Link to="/services" className="text-nature-sage hover:text-nature-mint font-medium inline-flex items-center">
                    Learn more
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button asChild className="bg-nature-sage hover:bg-nature-sage/90">
              <Link to="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Patients Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Read what our satisfied patients have to say about their experience at WeCare Dental.
            </p>
          </div>

          <div className="mt-8 relative">
            <Carousel className="mx-auto max-w-4xl">
              <CarouselContent>
                {testimonials.map((testimonial, index) => (
                  <CarouselItem key={index} className="md:basis-1/1">
                    <Card className="border-nature-mint/20 bg-nature-pale/30">
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row gap-6 items-center">
                          <div className="w-20 h-20 rounded-full overflow-hidden flex-shrink-0">
                            <img 
                              src={testimonial.image} 
                              alt={testimonial.name} 
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="text-lg italic text-gray-700 mb-4">"{testimonial.quote}"</div>
                            <div className="font-medium text-gray-900">{testimonial.name}</div>
                            <div className="text-gray-500">{testimonial.role}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="absolute -left-12 -right-12">
                <CarouselPrevious className="border-nature-mint text-nature-sage" />
                <CarouselNext className="border-nature-mint text-nature-sage" />
              </div>
            </Carousel>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-nature-gradient text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Schedule Your Visit?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Take the first step toward a healthier smile. Our friendly team is ready to assist you with scheduling your appointment.
            </p>
            <Button asChild size="lg" className="bg-white text-nature-sage hover:bg-nature-cream">
              <Link to="/book">Book Your Appointment</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Office Gallery */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Modern Dental Office</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Take a virtual tour of our state-of-the-art dental facility designed for your comfort.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              "https://images.unsplash.com/photo-1629909612337-f1527849cbb5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1606811951095-7e8b99a598e7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80"
            ].map((image, index) => (
              <div key={index} className="relative h-64 overflow-hidden rounded-lg shadow-md">
                <img 
                  src={image} 
                  alt={`Dental office view ${index + 1}`} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default Index;
